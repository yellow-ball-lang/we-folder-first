﻿#requires -Version 5.1
<#
  WE Folder First —— 卸载：把 Wallpaper Engine 自带界面恢复原样
  双击「卸载.cmd」即可。
#>
param([string]$WpePath = '')

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Say($m) { Write-Host $m }
function Fail($m) { Write-Host ''; Write-Host "!! $m" -ForegroundColor Red; exit 1 }

function Get-SteamLibs {
  $roots = @()
  foreach ($k in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
    try {
      $it = Get-ItemProperty $k -ErrorAction Stop
      if ($it.SteamPath) { $roots += $it.SteamPath }
      elseif ($it.InstallPath) { $roots += $it.InstallPath }
    } catch { }
  }
  $roots += 'C:\Program Files (x86)\Steam'
  $libs = @()
  foreach ($r in ($roots | Where-Object { $_ } | Select-Object -Unique)) {
    if (-not (Test-Path $r)) { continue }
    $libs += (Join-Path $r 'steamapps')
    $vdf = Join-Path $r 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
      try {
        $txt = Get-Content $vdf -Raw -ErrorAction Stop
        foreach ($m in [regex]::Matches($txt, '"path"\s+"([^"]+)"')) {
          $libs += (Join-Path ($m.Groups[1].Value -replace '\\\\', '\') 'steamapps')
        }
      } catch { }
    }
  }
  $libs | Where-Object { $_ } | Select-Object -Unique
}

$wpe = $null
if ($WpePath) { $wpe = $WpePath }
if (-not $wpe) {
  foreach ($lib in (Get-SteamLibs)) {
    $p = Join-Path $lib 'common\wallpaper_engine'
    if (Test-Path (Join-Path $p 'ui\dist\index.html')) { $wpe = $p; break }
  }
}
if (-not $wpe) {
  Say '没自动找到 Wallpaper Engine，请把它安装目录粘进来（含 wallpaper32.exe 的那个文件夹）：'
  $wpe = (Read-Host '安装目录').Trim('"').Trim()
  if (-not $wpe) { Fail '没有输入目录，已退出。' }
}

$dist = Join-Path $wpe 'ui\dist'
$cfgDir = Join-Path $dist 'scripts\wefp'
$orig = Join-Path $cfgDir 'index.html.orig'
Say "Wallpaper Engine: $wpe"

try {
  $indexNow = Join-Path $dist 'index.html'
  $injected = (Test-Path $indexNow) -and ([IO.File]::ReadAllText($indexNow) -match 'wefolderfirst\.js')
  if (-not (Test-Path $orig)) {
    if ($injected) {
      $htmlNow = [IO.File]::ReadAllText($indexNow)
      $stripped = [regex]::Replace($htmlNow, '\s*<script src="scripts/wefolderfirst\.js"></script>', '')
      if ($stripped -ne $htmlNow) {
        [IO.File]::WriteAllText($indexNow, $stripped, (New-Object Text.UTF8Encoding($false)))
        Say '没有备份，已直接从 index.html 里摘掉注入的 script 标签'
      } else {
        Say '没找到备份 index.html.orig，也没找到可摘的 script 标签，跳过还原'
      }
    } else {
      Say '没找到备份 index.html.orig，跳过还原（可能本来就没装过）'
    }
  } elseif (-not $injected) {
    Say '当前 index.html 不含注入（多半是 Steam 刚更新覆盖过），跳过还原，避免用旧备份盖掉新版文件'
  } else {
    Copy-Item $orig $indexNow -Force
    Say '已恢复原始 index.html'
  }
  $js = Join-Path $dist 'scripts\wefolderfirst.js'
  if (Test-Path $js) { Remove-Item $js -Force; Say '已删除脚本 wefolderfirst.js' }
  if (Test-Path $cfgDir) { Remove-Item $cfgDir -Recurse -Force; Say '已删除数据目录 scripts\wefp' }
} catch {
  Fail "删除失败（可能是权限问题）：$($_.Exception.Message)`n   试试右键「卸载.cmd」→ 以管理员身份运行。"
}

Say ''
Say '卸载完成。关掉 Wallpaper Engine 库窗口，再从托盘图标打开即可看到原样界面。'

# ---------- 4. 顺手取消开机自动修复（如果开过） ----------
$auto = Join-Path $here '自动修复.ps1'
if (Test-Path $auto) {
  try { & $auto -Remove -Quiet } catch { }
}