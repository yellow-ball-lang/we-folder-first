@echo off
chcp 65001 >nul
title WE Folder First - Enable auto repair
cd /d "%~dp0"
echo 开启「开机自动修复」：Steam 更新后，下次登录会自动把文件夹界面补回来。
echo 只写一条 HKCU 启动项，不需要管理员权限。
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0自动修复.ps1"
echo.
pause