@echo off
chcp 65001 >nul
title WE Folder First - Disable auto repair
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0自动修复.ps1" -Remove
echo.
pause