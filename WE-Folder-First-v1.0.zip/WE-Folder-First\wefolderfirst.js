(function(){
  var K='[WEFP]', LSK='wefp.ctlaid', F='http://wpx.internal/__file/';
  var WS='{{WS}}/';              // 本目录（放 groups.json / ctl.json）
  var WPE='{{WPE}}';             // Wallpaper Engine 安装目录
  function L(){ try{ console.log(K+' '+Array.prototype.slice.call(arguments).map(function(a){ return typeof a==='string'?a:JSON.stringify(a); }).join(' ')); }catch(e){} }
  var css=document.createElement('style');
  css.textContent='html.wefp-hidegrid .browseWallpaperGridParent{display:none!important}'
    +'.browseWallpapersWorkshopStatus{display:none!important}'
    +'.browseAlert .uib-alert,.browseAlert .alert{transition:none!important}'
    +'#wefp-fab{position:fixed;width:54px;height:54px;border-radius:50%;z-index:2147483100;cursor:grab;'
    +'display:flex;align-items:center;justify-content:center;font-size:24px;line-height:1;user-select:none;'
    +'background:rgba(28,30,40,.94);border:1px solid rgba(255,255,255,.22);color:#fff;background-size:cover;'
    +'background-position:center;background-repeat:no-repeat;'
    +'box-shadow:0 6px 20px rgba(0,0,0,.55);transition:transform .12s ease,box-shadow .12s ease}'
    +'#wefp-fab.hasimg{border-color:rgba(255,255,255,.45);text-shadow:none}'
    +'#wefp-fab::before{content:"";position:absolute;inset:-6px;border-radius:inherit}'
    +'#wefp-set{position:fixed;z-index:2147483200;display:none;width:272px;padding:14px;border-radius:10px;'
    +'background:#14161d;color:#e8e8ee;border:1px solid #2b3040;box-shadow:0 10px 34px rgba(0,0,0,.6);'
    +'font:13px/1.6 "Segoe UI","Microsoft YaHei",sans-serif}'
    +'#wefp-set b{font-size:13px;color:#fff}'
    +'#wefp-set .r{display:flex;gap:8px;margin-top:10px}'
    +'#wefp-set button{flex:1;cursor:pointer;background:#232838;color:#dfe3f0;border:1px solid #333a4d;'
    +'border-radius:6px;padding:6px 8px;font:12px "Segoe UI","Microsoft YaHei",sans-serif}'
    +'#wefp-set button:hover{background:#2c3346}'
    +'#wefp-set .hint{color:#7a8194;font-size:11px;margin-top:8px}'
    +'#wefp-fab:hover{transform:scale(1.06);box-shadow:0 8px 26px rgba(0,0,0,.65)}'
    +'#wefp-toast{position:fixed;left:50%;transform:translateX(-50%);top:12px;z-index:99999;display:none;opacity:0;transition:opacity .3s ease;'
    +'max-width:70vw;padding:10px 16px;border-radius:8px;background:rgba(20,20,26,.95);color:#ffd9a0;'
    +'font:14px/1.5 "Microsoft YaHei",system-ui;border:1px solid rgba(255,190,90,.45);box-shadow:0 6px 24px rgba(0,0,0,.5)}';
  (document.head||document.documentElement).appendChild(css);
  document.documentElement.classList.add('wefp-hidegrid');
  window.__wefp={L:L,ver:'33'};
  L('boot v33');
  var S=null, overlay=null, lib={groups:[],total:0,folders:[]}, sig='', path=[];

  function allScopes(){
    var out=[];
    try{
      var inj=angular.element(document.body).injector(); if(!inj) return out;
      var q=[inj.get('$rootScope')], n=0;
      while(q.length && n<6000){ var s=q.shift(); n++; if(s.filterAllTags && s.filterAllTags.length) out.push(s); var c=s.$$childHead; while(c){ q.push(c); c=c.$$nextSibling; } }
    }catch(e){ L('scopeERR '+e.message); }
    return out;
  }
  function pickScope(){
    var cands=allScopes(); if(!cands.length) return null;
    cands.sort(function(a,b){
      var fa=(a.folders||[]).filter(function(x){return x&&x.type==='folder';}).length;
      var fb=(b.folders||[]).filter(function(x){return x&&x.type==='folder';}).length;
      if(fa!==fb) return fb-fa;
      return ((b.wallpapers||[]).length)-((a.wallpapers||[]).length);
    });
    return cands[0];
  }
  function isFolder(f){ return !!f && (f.type==='folder'||f.items||f.subfolders); }
  function roots(){
    var fromCfg=(lib&&lib.folders)||[];
    var fromApp=(S&&S.folders)||[];
    var src=fromCfg.length?fromCfg:fromApp;
    return src.filter(isFolder);
  }
  function subsOf(f){ return ((f&&f.subfolders)||[]).filter(isFolder); }
  function validKeys(){
    // 只有「已安装」源里的 wallpapers 和文件夹 items 是同一批数据；
    // 在发现/创意工坊页读到的是那边的列表，拿它算会把所有文件夹显示成 0。
    if(!S || !S.sourceIsInstalled) return null;
    var w=S.wallpapers||[]; if(!w.length) return null;
    var m={}; for(var i=0;i<w.length;i++){ var x=w[i]; var k=(x.workshopid!=null&&x.workshopid!=='')?x.workshopid:x.file; if(k!=null) m[String(k)]=1; }
    return m;
  }
  function itemsCount(f,vk){
    if(!f||!f.items) return 0;
    var keys=Object.keys(f.items); if(!vk) return keys.length;
    var n=0; for(var i=0;i<keys.length;i++){ if(vk[keys[i]]) n++; } return n;
  }
  function countAll(f,vk){ var n=itemsCount(f,vk); subsOf(f).forEach(function(s){ n+=countAll(s,vk); }); return n; }
  function level(){ if(!path.length) return roots(); return subsOf(path[path.length-1]); }

  function gridEl(){ return document.querySelector('.browseWallpaperGridParent'); }
  function gridScroller(){
    var g=gridEl(); if(!g) return null;
    var stack=[g], seen=0;
    while(stack.length && seen<500){
      var e=stack.shift(); seen++;
      try{ var cs=getComputedStyle(e); if(e.scrollHeight>e.clientHeight+8 && /(auto|scroll)/.test(cs.overflowY)) return e; }catch(x){}
      for(var i=0;i<e.children.length;i++) stack.push(e.children[i]);
    }
    return document.scrollingElement||document.documentElement;
  }
  function hideGrid(){ document.documentElement.classList.add('wefp-hidegrid'); }
  function showGrid(){
    document.documentElement.classList.remove('wefp-hidegrid');
    try{ window.dispatchEvent(new Event('resize')); }catch(e){}
    setTimeout(function(){ try{ var sc=gridScroller(); if(sc) sc.scrollTop=0; }catch(e){} },150);
  }
  function clickChipByLabel(label){
    var items=document.querySelectorAll('.browseWallpaperFilter .filterItem');
    for(var i=0;i<items.length;i++){ var t=items[i].querySelector('.checkBoxTitle'); if(t && t.textContent.trim()===label){ var cb=items[i].querySelector('.checkBoxOuter'); if(cb){ cb.click(); return true; } } }
    return false;
  }
  function resetChips(){ var on=document.querySelectorAll('.browseWallpaperFilter .checkBoxTitle.successText'); if(on&&on.length){ var r=document.querySelector('.browseWallpaperFilter [ng-click="callbackResetFilter()"]'); if(r){ r.click(); return true; } } return false; }
  function gotoRoot(){
    try{
      if(S && S.currentFolder && S.navigateFolder){ L('leaveFolder -> root'); S.navigateFolder(); S.$applyAsync(); }
    }catch(e){ L('rootERR '+e.message); }
    path=[];
  }
  function clearTagFilter(){
    var n=0;
    try{
      if(S && S.filter){
        if(S.filter.tags){ for(var k in S.filter.tags){ if(S.filter.tags.hasOwnProperty(k) && S.filter.tags[k]!==true){ S.filter.tags[k]=true; n++; } } }
        if(typeof S.filter.text==='string' && S.filter.text){ S.filter.text=''; n++; }
      }
    }catch(e){ L('clearTagERR '+e.message); }
    if(n){ L('clearTag '+n); try{ if(S) S.$applyAsync(); }catch(e){} }
    return n;
  }
  function ensureInstalledSource(cb){
    var switched=false;
    try{
      if(S && !S.sourceIsInstalled && S.setListSourceInstalled){
        L('switchSource installed (was '+(S.source||'?')+')');
        S.setListSourceInstalled(); S.$applyAsync(); switched=true;
      }
    }catch(e){ L('srcERR '+e.message); }
    if(switched){ setTimeout(cb,350); } else { cb(); }
  }
  function openFolder(folder){
    L('openFolder '+folder.title);
    if(overlay) overlay.style.display='none';
    clearTagFilter();
    ensureInstalledSource(function(){
      try{ S.navigateFolder(folder); S.$applyAsync(); }catch(e){ L('navERR '+e.message); }
    });
    setTimeout(function(){ syncChipsAll(); },700);
    setTimeout(showGrid,750);
  }
  function enter(folder){
    if(overlay) overlay.style.display='block';
    if(subsOf(folder).length){ path.push(folder); renderBody(); try{ if(overlay) overlay.scrollTop=0; }catch(e){} }
    else { openFolder(folder); }
  }
  function tagValueOf(label){
    try{ var a=S&&S.filterAllTags||[]; for(var i=0;i<a.length;i++){ if(a[i].label===label) return a[i].value; } }catch(e){}
    return null;
  }
  function syncChipsAll(){
    try{
      var items=document.querySelectorAll('.browseWallpaperFilter .filterItem'), n=0;
      for(var i=0;i<items.length;i++){
        var tt=items[i].querySelector('.checkBoxTitle'); if(!tt) continue;
        if(tt.className.indexOf('successText')<0){ tt.className+=' successText'; }
        n++;
      }
      L('syncChipsAll marked='+n+' total='+items.length);
    }catch(e){ L('syncAllERR '+e.message); }
  }
  function syncChips(val){
    try{
      var items=document.querySelectorAll('.browseWallpaperFilter .filterItem'), n=0, a=S&&S.filterAllTags||[];
      for(var i=0;i<items.length;i++){
        var it=items[i], tt=it.querySelector('.checkBoxTitle'); if(!tt) continue;
        var lab=(tt.textContent||'').trim(), v=null;
        for(var j=0;j<a.length;j++){ if(a[j].label===lab){ v=a[j].value; break; } }
        if(!v) continue;
        if(v===val){ if(tt.className.indexOf('successText')<0) tt.className+=' successText'; n++; }
        else{ tt.className=tt.className.replace(/\s*successText/g,''); }
      }
      L('syncChips '+val+' marked='+n+' total='+items.length);
    }catch(e){ L('syncERR '+e.message); }
  }
  // 22 版：toast 0.3s 淡入淡出（原来瞬间消失，看起来像闪一下）
  function toast(msg,ms){
    try{
      var d=document.getElementById('wefp-toast');
      if(!d){ d=document.createElement('div'); d.id='wefp-toast'; document.body.appendChild(d); }
      d.textContent=msg;
      if(d.style.display!=='block'){ d.style.display='block'; d.style.opacity='0'; void d.offsetWidth; }
      d.style.opacity='1';
      var tok=(toast._tok=(toast._tok||0)+1);
      clearTimeout(toast._t); clearTimeout(toast._h);
      toast._t=setTimeout(function(){
        if(tok!==toast._tok) return;
        d.style.opacity='0';
        toast._h=setTimeout(function(){ if(tok===toast._tok) d.style.display='none'; },330);
      }, ms||6000);
    }catch(e){}
  }
  function openTag(label){
    L('openTag '+label);
    if(overlay) overlay.style.display='none';
    ensureInstalledSource(function(){ openTagApply(label); });
  }
  function openTagApply(label){
    gotoRoot();
    var val=tagValueOf(label), ok=false;
    if(val && S && S.filter){
      try{
        if(!S.filter.tags) S.filter.tags={};
        for(var k in S.filter.tags){ if(S.filter.tags.hasOwnProperty(k)) S.filter.tags[k]=false; }
        S.filter.tags[val]=true;
        try{ if(S.filterStatus) S.filterStatus.tags=true; if(S.showFilter) S.showFilter.base=true; }catch(e){}
        try{ S.$applyAsync(); }catch(e){}
        ok=true; L('tagModel '+label+'='+val);
        syncChips(val); setTimeout(function(){ syncChips(val); },450);
      }catch(e){ L('tagModelERR '+e.message); }
    }
    if(!ok){
      var hr=resetChips();
      setTimeout(function(){ var r2=clickChipByLabel(label); L('chipFallback '+label+'->'+r2); setTimeout(showGrid, r2?700:200); }, hr?500:0);
      return;
    }
    setTimeout(function(){
      var on=document.querySelectorAll('.browseWallpaperFilter .checkBoxTitle.successText');
      L('tagCheck '+label+' chips='+on.length);
      showGrid();
      setTimeout(function(){
        var n=(S&&S.wallpapers&&S.wallpapers.length)||0;
        if(n===0) toast('壁纸列表这次没被引擎加载出来（常见于刷新过库窗口）。请关掉这个窗口、从托盘图标重新打开；急用可以先点「我的文件夹」，文件夹不走这个列表。');
      },1400);
    },700);
  }
  function openAll(){
    L('openAll');
    if(overlay) overlay.style.display='none';
    ensureInstalledSource(openAllApply);
  }
  function openAllApply(){
    try{
      if(S&&S.filter&&S.filter.tags){ for(var k in S.filter.tags){ if(S.filter.tags.hasOwnProperty(k)) S.filter.tags[k]=true; } }
      if(S&&S.filter&&typeof S.filter.text==='string'){ S.filter.text=''; }
      gotoRoot();
      if(S) S.$applyAsync();
    }catch(e){ L('allERR '+e.message); }
    setTimeout(function(){ syncChipsAll(); L('allCount '+((S&&S.wallpapers&&S.wallpapers.length)||0)); },500);
    setTimeout(showGrid,600);
  }
  function backToFolders(){
    hideGrid();
    gotoRoot();
    openPanel(); renderBody();
  }
  var fab=null, lastLibFetch=0;
  // 30 秒最多重读一次文件夹树：用户在 WPE 里新建的文件夹，不用重开窗口就能出现在面板里
  function refreshLib(){
    var now=Date.now();
    if(now-lastLibFetch<30000) return;
    lastLibFetch=now;
    loadLib(function(){ renderBody(); });
  }
  function openPanel(){ if(overlay) overlay.style.display='block'; hideGrid(); refreshLib(); }
  function closePanel(){ if(overlay) overlay.style.display='none'; }
  function togglePanel(){
    var open=overlay && overlay.style.display!=='none' && overlay.style.display!=='';
    if(open){ closePanel(); showGrid(); } else { openPanel(); }
    L('panel '+(open?'closed':'opened'));
  }
  var fabCfg={img:'',size:40,shape:'circle',start:'panel'};
  function loadFabPrefs(){
    try{ var c=JSON.parse(localStorage.getItem('wefp.fabcfg')||'null'); if(c){ if(c.size) fabCfg.size=+c.size; if(c.shape) fabCfg.shape=c.shape; if(c.start) fabCfg.start=c.start; } }catch(e){}
  }
  function saveFabPrefs(){ try{ localStorage.setItem('wefp.fabcfg', JSON.stringify({size:fabCfg.size,shape:fabCfg.shape,start:fabCfg.start})); }catch(e){} }
  // 22 版：窗口顶部那条标题栏是系统级拖动区，鼠标按上去不会交给网页，
  // 所以悬浮球不能停在最上面，否则既拖不动、左键也点不开设置。
  function safeTop(){
    var tb=document.querySelector('.titlebar');
    var h=tb?Math.round(tb.getBoundingClientRect().height):30;
    if(!h||h<12) h=30;
    return h;
  }
  function clampFabPos(notify){
    if(!fab) return;
    var bw=fab.offsetWidth||54, bh=fab.offsetHeight||54;
    var st=safeTop();
    var L2=parseFloat(fab.style.left)||0, T2=parseFloat(fab.style.top)||0;
    L2=Math.max(4,Math.min(window.innerWidth-bw-4,L2));
    var want=T2;
    T2=Math.max(st,Math.min(window.innerHeight-bh-6,T2));
    fab.style.left=L2+'px'; fab.style.top=T2+'px';
    if(notify && want<T2){ toast('顶边是窗口自己的拖动条，悬浮球自动让开了一点', 800); }
  }
  function applyFabCfg(){
    if(!fab) return;
    var s=Math.max(20,Math.min(140,+fabCfg.size||40)), rect=(fabCfg.shape==='rect');
    fab.style.width=(rect?Math.round(s*1.6):s)+'px';
    fab.style.height=s+'px';
    fab.style.borderRadius=rect?(Math.round(s*0.28)+'px'):'50%';
    fab.style.fontSize=Math.round(s*0.46)+'px';
    fabCfg.size=s;
    clampFabPos();

  }
  function markShapeBtns(){
    var pair=[['wefp-shape-c','circle'],['wefp-shape-r','rect']];
    for(var i=0;i<pair.length;i++){
      var b=document.getElementById(pair[i][0]);
      if(!b) continue;
      var on=(fabCfg.shape===pair[i][1]);
      b.style.background=on?'#3b4668':'#232838';
      b.style.borderColor=on?'#5b6a99':'#333a4d';
      b.style.color=on?'#fff':'#dfe3f0';
    }
    var sg=document.getElementById('wefp-sizeval'); if(sg) sg.textContent=(+fabCfg.size||40)+' px';
  }
  function markStartBtns(){
    var pair=[['wefp-start-p','panel'],['wefp-start-b','ball']];
    for(var i=0;i<pair.length;i++){
      var b=document.getElementById(pair[i][0]); if(!b) continue;
      var on=(fabCfg.start===pair[i][1]);
      b.style.background=on?'#3b4668':'#232838';
      b.style.borderColor=on?'#5b6a99':'#333a4d';
      b.style.color=on?'#fff':'#dfe3f0';
    }
  }
  function applyFabImage(src,isData){
    if(!fab) return;
    if(!src){ fab.style.backgroundImage=''; fab.textContent='\uD83D\uDCC1'; fab.classList.remove('hasimg'); return; }
    if(isData){ fab.style.backgroundImage='url("'+src+'")'; fab.textContent=''; fab.classList.add('hasimg'); return; }
    fetch(F+encodeURIComponent(src)).then(function(r){ return r.blob(); }).then(function(b){
      var fr=new FileReader();
      fr.onload=function(){ try{ localStorage.setItem('wefp.fabimg', fr.result); }catch(e){} applyFabImage(String(fr.result), true); L('fabImg '+src); };
      fr.readAsDataURL(b);
    }).catch(function(e){ L('fabImgERR '+src+' '+e.message); });
  }
  // 安装后本目录就是 <dist>\scripts\wefp，config.json 直接在它下面；
  // 早期开发布局把配置放在 <目录>\wefp\config.json —— 两个位置都认，避免读不到配置。
  function readCfg(){
    var cands=[WS+'config.json', WS+'wefp/config.json'];
    function step(i){
      if(i>=cands.length) return Promise.reject(new Error('no config'));
      return fetch(F+encodeURIComponent(cands[i])).then(function(r){
        if(!r.ok) throw new Error('http '+r.status);
        return r.text();
      }).then(function(t){
        var c=JSON.parse(t);
        L('cfg from '+cands[i]);
        return c;
      }).catch(function(e){ L('cfgTry '+cands[i]+' '+((e&&e.message)||'')); return step(i+1); });
    }
    return step(0);
  }
  function loadFabImage(){
    var local=null; try{ local=localStorage.getItem('wefp.fabimg'); }catch(e){}
    function useLocal(){ if(local) applyFabImage(local,true); }
    readCfg().then(function(c){
      if(c&&c.startMode){ fabCfg.start=(c.startMode==='ball'?'ball':'panel'); if(overlay){ if(fabCfg.start==='ball'){ closePanel(); hideGrid(); } else { openPanel(); } } }
      var userPick=false; try{ userPick=localStorage.getItem('wefp.fabuser')==='1'; }catch(e){}
      if(c&&c.fabImage){
        // fabForce=true 时以 config.json 为准（用于随包分发默认图标）；
        // 但用户自己在设置里选过图（wefp.fabuser=1）就以用户的为准，不再回退。
        if(!local || (c.fabForce && !userPick)){
          try{ localStorage.removeItem('wefp.fabimg'); }catch(e){}
          fabCfg.img=c.fabImage;
          if(c.fabSize) fabCfg.size=+c.fabSize;
          if(c.fabShape) fabCfg.shape=c.fabShape;
          applyFabCfg(); markShapeBtns(); applyFabImage(c.fabImage,false);
          return;
        }
      }
      if(!(c&&c.fabImage)){
        // 没有默认图标：回到最初始的文件夹图标。
        // 本机缓存里若存的是「旧的默认图」(用户从没自己选过) 就一并清掉，避免旧图一直留着。
        if(!userPick){ try{ localStorage.removeItem('wefp.fabimg'); }catch(e){} applyFabImage('',true); return; }
      }
      useLocal();
    }).catch(function(){ useLocal(); });
  }
  function pickFabImage(){
    var inp=document.getElementById('wefp-file');
    if(!inp){ inp=document.createElement('input'); inp.type='file'; inp.accept='image/*'; inp.id='wefp-file'; inp.style.display='none'; document.body.appendChild(inp); }
    inp.onchange=function(){
      var f=inp.files&&inp.files[0]; if(!f) return;
      var fr=new FileReader();
      fr.onload=function(){
        var img=new Image();
        img.onload=function(){
          try{
            var S2=128, cv=document.createElement('canvas'); cv.width=S2; cv.height=S2;
            var ctx=cv.getContext('2d');
            var sc=Math.max(S2/img.width, S2/img.height);
            var w=img.width*sc, h=img.height*sc;
            ctx.drawImage(img,(S2-w)/2,(S2-h)/2,w,h);
            var d=cv.toDataURL('image/png');
            localStorage.setItem('wefp.fabimg', d); localStorage.setItem('wefp.fabuser','1'); applyFabImage(d,true); L('fabImg picked(user)');
          }catch(e){ L('fabPickERR '+e.message); }
        };
        img.src=String(fr.result);
      };
      fr.readAsDataURL(f);
      closeFabSet();
    };
    inp.value=''; inp.click();
  }
  function closeFabSet(){ var s=document.getElementById('wefp-set'); if(s) s.style.display='none'; }
  function fabSetVisible(){ var s=document.getElementById('wefp-set'); return !!(s && s.style.display==='block'); }
  function toggleFabSet(){ if(fabSetVisible()){ closeFabSet(); } else { openFabSet(); } }
  function openFabSet(){
    var s=document.getElementById('wefp-set');
    if(!s){
      s=el('div',null,''); s.id='wefp-set';
      s.appendChild(el('b','悬浮球设置','display:block;margin-bottom:4px'));
      s.appendChild(el('div','点「选择图片」挑一张图当图标；图片会缩到 128×128 后只存在本机浏览器里。','color:#9aa1b4;font-size:12px'));
      var sizeRow=el('div',null,'margin-top:12px');
      var sizeTop=el('div',null,'display:flex;align-items:baseline;justify-content:space-between');
      sizeTop.appendChild(el('span','大小','color:#c9cfe0'));
      var sizeVal=el('span',(fabCfg.size||40)+' px','color:#8f98ad;font-size:12px'); sizeVal.id='wefp-sizeval';
      sizeTop.appendChild(sizeVal); sizeRow.appendChild(sizeTop);
      var rng=document.createElement('input'); rng.type='range'; rng.min='24'; rng.max='96'; rng.step='2';
      rng.value=String(fabCfg.size||40); rng.style.cssText='width:100%;margin:6px 0 0;accent-color:#6f86d6;cursor:pointer';
      rng.oninput=function(){ fabCfg.size=+rng.value; applyFabCfg(); saveFabPrefs(); markShapeBtns(); };
      sizeRow.appendChild(rng);
      s.appendChild(sizeRow);
      var shapeRow=el('div',null,'margin-top:10px');
      shapeRow.appendChild(el('span','形状','color:#c9cfe0'));
      var sr=el('div',null,''); sr.className='r';
      var bc=el('button','圆形'); bc.id='wefp-shape-c';
      bc.onclick=function(){ fabCfg.shape='circle'; applyFabCfg(); saveFabPrefs(); markShapeBtns(); };
      var br=el('button','圆角矩形'); br.id='wefp-shape-r';
      br.onclick=function(){ fabCfg.shape='rect'; applyFabCfg(); saveFabPrefs(); markShapeBtns(); };
      sr.appendChild(bc); sr.appendChild(br); shapeRow.appendChild(sr);
      s.appendChild(shapeRow);
      var startRow=el('div',null,'margin-top:10px');
      startRow.appendChild(el('span','打开时','color:#c9cfe0'));
      var sr2=el('div',null,''); sr2.className='r';
      var bp=el('button','文件夹面板'); bp.id='wefp-start-p';
      bp.onclick=function(){ fabCfg.start='panel'; saveFabPrefs(); markStartBtns(); openPanel(); };
      var bb=el('button','只显示球'); bb.id='wefp-start-b';
      bb.onclick=function(){ fabCfg.start='ball'; saveFabPrefs(); markStartBtns(); closePanel(); hideGrid(); };
      sr2.appendChild(bp); sr2.appendChild(bb); startRow.appendChild(sr2);
      startRow.appendChild(el('div','下次打开库窗口时用哪种开场；点了立即生效。','color:#6f7688;font-size:11px;margin-top:2px'));
      s.appendChild(startRow);      var r=el('div',null,''); r.className='r';
      var b1=el('button','选择图片'); b1.onclick=pickFabImage;
      var b2=el('button','恢复默认'); b2.onclick=function(){ try{ localStorage.removeItem('wefp.fabimg'); localStorage.removeItem('wefp.fabuser'); }catch(e){} applyFabImage('',true); loadFabImage(); closeFabSet(); };
      r.appendChild(b1); r.appendChild(b2); s.appendChild(r);

      var b3=el('button','关闭'); b3.style.marginTop='6px'; b3.style.width='100%'; b3.onclick=closeFabSet; s.appendChild(b3);
      document.body.appendChild(s);
    }
    markShapeBtns(); markStartBtns();
    var l=parseFloat(fab.style.left)||0, t=parseFloat(fab.style.top)||0;
    s.style.display='block';
    var sw=s.offsetWidth||260, sh=s.offsetHeight||150;
    var L2=Math.max(6,Math.min(window.innerWidth-sw-6, l-sw-14));
    var T2=Math.max(6,Math.min(window.innerHeight-sh-6, t-sh/2));
    s.style.left=(l-sw-14>6?l-sw-14:L2)+'px'; s.style.top=T2+'px';
  }
  function ensureFab(){
    if(fab) return;
    loadFabPrefs();
    fab=el('div','\uD83D\uDCC1','');
    fab.id='wefp-fab'; fab.title='点我打开文件夹（可拖动；右键或按住不动才开设置）';
    var pos=null;
    try{ pos=JSON.parse(localStorage.getItem('wefp.fabpos')||'null'); }catch(e){}
    var w=(+fabCfg.size||40), l=(pos&&pos.l!=null)?pos.l:(window.innerWidth-w-18), t=(pos&&pos.t!=null)?pos.t:Math.round(window.innerHeight*0.42);
    fab.style.left=l+'px'; fab.style.top=t+'px';
    document.body.appendChild(fab);
    applyFabCfg();
    var dragging=false, moved=false, sx=0, sy=0, ox=0, oy=0;
    function clamp(){ clampFabPos(true); }

    // 21 版：左键"按住 650ms 不动"才开设置（双击被系统识别为 dblclick，误触概率高）
    var pressTimer=null, longPressed=false;
    function clearPress(){ if(pressTimer){ clearTimeout(pressTimer); pressTimer=null; } }
    fab.addEventListener('mousedown',function(e){
      if(e.button!==0) return;
      dragging=true; moved=false; longPressed=false; sx=e.clientX; sy=e.clientY;
      ox=parseFloat(fab.style.left)||0; oy=parseFloat(fab.style.top)||0;
      fab.style.cursor='grabbing'; e.preventDefault(); e.stopPropagation();
      closeFabSet();
      clearPress();
      pressTimer=setTimeout(function(){
        pressTimer=null;
        if(!dragging || moved) return;
        longPressed=true; dragging=false; fab.style.cursor='grab';
        L('fabLongPress');
        toggleFabSet();
      },650);
    });
    fab.addEventListener('contextmenu',function(e){
      e.preventDefault(); e.stopPropagation(); toggleFabSet();
    });
    // 21 版：双击不再打开设置（左键连点两次会被系统当成 dblclick，容易误触）
    fab.addEventListener('dblclick',function(e){ e.preventDefault(); e.stopPropagation(); });
    document.addEventListener('keydown',function(e){
    if(e.key==='Escape'){ closeFabSet(); }
  });
  document.addEventListener('mousemove',function(e){
      if(!dragging) return;
      var dx=e.clientX-sx, dy=e.clientY-sy;
      if(Math.abs(dx)+Math.abs(dy)>3){ moved=true; clearPress(); }
      fab.style.left=(ox+dx)+'px'; fab.style.top=(oy+dy)+'px';
      e.preventDefault();
    },true);
    document.addEventListener('mouseup',function(e){
      if(!dragging) return;
      dragging=false; clearPress(); fab.style.cursor='grab'; clamp();
      if(longPressed){ longPressed=false; return; }
      try{ localStorage.setItem('wefp.fabpos', JSON.stringify({l:parseFloat(fab.style.left),t:parseFloat(fab.style.top)})); }catch(err){}
      if(!moved) togglePanel();
    },true);
    loadFabImage();
  }
  function el(tag,text,cssText){ var d=document.createElement(tag); if(text!==null&&text!==undefined) d.textContent=text; if(cssText) d.style.cssText=cssText; return d; }
  function card(title,sub,onclick,accent){
    var c=el('div',null,'cursor:pointer;background:'+(accent?'#1b2233':'#181a22')+';border:1px solid '+(accent?'#2f3d5c':'#262936')+';border-radius:10px;padding:14px 16px 12px;transition:background .12s,border-color .12s');
    c.onmouseenter=function(){ c.style.background='#20232e'; c.style.borderColor='#3d4256'; };
    c.onmouseleave=function(){ c.style.background=accent?'#1b2233':'#181a22'; c.style.borderColor=accent?'#2f3d5c':'#262936'; };
    c.appendChild(el('div',title,'font-size:15px;font-weight:600;margin-bottom:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis'));
    c.appendChild(el('div',sub||'','font-size:12px;color:#767c92'));
    c.onclick=onclick;
    return c;
  }
  function section(parent,title,hint,cols){
    var h=el('div',null,'display:flex;align-items:baseline;gap:10px;margin:0 0 12px 0');
    h.appendChild(el('div',title,'font-size:15px;font-weight:600;color:#cfd4e6'));
    if(hint) h.appendChild(el('div',hint,'font-size:12px;color:#6a7086'));
    parent.appendChild(h);
    var g=el('div',null,'display:grid;grid-template-columns:repeat(auto-fill,minmax('+cols+',1fr));gap:12px;margin-bottom:26px');
    parent.appendChild(g);
    return g;
  }
  function crumbLink(label,depth){
    var a=el('span',label,'cursor:pointer;color:#aab0c6');
    a.onmouseenter=function(){ a.style.color='#e8e8ee'; };
    a.onmouseleave=function(){ a.style.color='#aab0c6'; };
    a.onclick=function(){ path=path.slice(0,depth); renderBody(); };
    return a;
  }
  var vkMap=null;
  // 标签数量每次实时从已加载的壁纸里数，避免「装完就不再更新」（groups.json 是安装时扫的）
  function tagCounts(){
    if(!S || !S.sourceIsInstalled) return null;
    var w=S.wallpapers||[]; if(!w.length) return null;
    var m={};
    for(var i=0;i<w.length;i++){
      // 引擎里 wallpaper.tags 是逗号分隔的字符串（scripts.js: angular.isString(t.tags)&&t.tags.indexOf(e)），
      // 少数情况下是数组，两种都要按「整词」统计，不能逐字符遍历
      var ts=w[i].tags;
      if(ts===null||ts===undefined) continue;
      var parts=(typeof ts==='string')?ts.split(','):(ts.length?ts:[]);
      for(var j=0;j<parts.length;j++){
        var t=String(parts[j]).replace(/^\s+|\s+$/g,'');
        if(t) m[t]=(m[t]||0)+1;
      }
    }
    return m;
  }
  function folderCard(f){
    var sub=countAll(f,vkMap), sc=subsOf(f).length;
    return card(f.title,(sc?sc+' 个子文件夹 · ':'')+sub+' 个壁纸',function(){ enter(f); });
  }
  var lastPathSig='';
  function renderBody(forceTop){
    var body=document.getElementById('wefp-body'); if(!body) return;
    S=pickScope(); if(!S) return;
    // 1.5s 一次的自动刷新会重排 DOM，把用户的滚动位置拽回顶部，这里先记下来再还原
    var pathSig=path.map(function(f){ return f.title; }).join('/');
    var keepScroll=(!forceTop && pathSig===lastPathSig && overlay)?overlay.scrollTop:0;
    body.innerHTML='';
    vkMap=validKeys();
    var tc=tagCounts();
    var lv=level();
    var tagMap={}; ((S.filterAllTags)||[]).forEach(function(t){ tagMap[t.value]=t.label; });
    var items=(lib&&lib.groups)||[];
    // groups.json 缺失或为空时（例如安装时一个壁纸都没扫到），不能整块标签区消失：
    // 退回引擎自带的 filterAllTags 名单，数量交给 tagCounts 现场统计
    if(!items.length && S.filterAllTags && S.filterAllTags.length){
      items=S.filterAllTags.map(function(t){ return { name:t.value, count:0 }; });
    }
    if(path.length){
      var crumb=el('div',null,'display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin:0 0 18px 0;font-size:13px');
      crumb.appendChild(crumbLink('我的文件夹',0));
      for(var i=0;i<path.length;i++){ crumb.appendChild(el('span','›','color:#4a4f63')); crumb.appendChild(crumbLink(path[i].title,i+1)); }
      body.appendChild(crumb);
      var cur=path[path.length-1];
      var own=itemsCount(cur,vkMap);
      if(own>0){
        var g0=section(body,'这个文件夹',own+' 个壁纸','230px');
        g0.appendChild(card(cur.title,own+' 个壁纸 · 点开看',function(){ openFolder(cur); },true));
      }
      if(lv.length){
        var gs=section(body,'子文件夹',lv.length+' 个','230px');
        lv.forEach(function(f){ gs.appendChild(folderCard(f)); });
      }
      if(!own && !lv.length){
        body.appendChild(el('div','这个文件夹是空的','color:#6a7086;font-size:13px;margin:6px 0 18px'));
      }
    } else {
      if(lv.length){
        var g1=section(body,'我的文件夹',lv.length+' 个','230px');
        lv.forEach(function(f){ g1.appendChild(folderCard(f)); });
      }
      if(items.length){
        var g2=section(body,'按标签分类','有内容的标签 · '+items.length+' 个','150px');
        var shownTags=0;
        items.forEach(function(it){
          var label=tagMap[it.name]; if(!label) return;
          var cnt=(tc && typeof tc[it.name]==='number')?tc[it.name]:it.count;
          if(tc && cnt<=0) return;
          shownTags++;
          g2.appendChild(card(label,cnt+' 个',function(){ openTag(label); }));
        });
        if(!shownTags && g2.parentNode){ g2.parentNode.removeChild(g2); }
      }
      var g3=section(body,'','','150px');
      g3.appendChild(card('全部壁纸','不做筛选，显示所有',openAll,false));
    }
    lastPathSig=pathSig;
    if(overlay){ try{ overlay.scrollTop=keepScroll; }catch(e){} }
    var nsig=path.length+'/'+lv.length+'/'+items.length;
    if(nsig!==sig){ sig=nsig; L('render path='+path.length+' level='+lv.length+' tags='+items.length+' folders='+roots().length); }
  }
  function buildUI(){
    loadFabPrefs();
    if(document.getElementById('wefp-overlay')) return;
    overlay=el('div',null,'position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483000;background:#0f1015;color:#e8e8ee;font-family:"Segoe UI","Microsoft YaHei",sans-serif;overflow:auto;padding:34px 40px 40px;box-sizing:border-box');
    overlay.id='wefp-overlay';
    var head=el('div',null,'display:flex;align-items:baseline;justify-content:space-between;margin-bottom:22px');
    head.appendChild(el('div','选择文件夹','font-size:25px;font-weight:600;letter-spacing:.4px'));
    head.appendChild(el('div','先选文件夹，再看壁纸','font-size:12px;color:#6a7086'));
    overlay.appendChild(head);
    var body=el('div',null,''); body.id='wefp-body'; overlay.appendChild(body);
    document.body.appendChild(overlay);
    renderBody();
    overlay.style.display=(fabCfg.start==='ball'?'none':'block');
    ensureFab();
  }
  function findFolders(o,depth){
    if(!o||depth>7) return null;
    if(Object.prototype.toString.call(o)==='[object Array]'){
      for(var i=0;i<o.length;i++){ var r=findFolders(o[i],depth+1); if(r) return r; }
      return null;
    }
    if(typeof o!=='object') return null;
    for(var k in o){
      if(k==='folders' && Object.prototype.toString.call(o[k])==='[object Array]' && o[k].length) return o[k];
      var r=findFolders(o[k],depth+1); if(r) return r;
    }
    return null;
  }
  function loadLib(cb){
    var pending=2, done=false;
    function fin(){ if(done) return; if(--pending<=0){ done=true; cb(); } }
    fetch(F+encodeURIComponent(WS+'groups.json')).then(function(r){ return r.json(); }).then(function(d){ if(d&&d.groups){ lib.groups=d.groups; lib.total=d.total||0; } fin(); }).catch(function(e){ L('libERR '+e.message); fin(); });
    fetch(F+encodeURIComponent(WPE+'/config.json')).then(function(r){ return r.json(); }).then(function(d){ var fs=findFolders(d,0); if(fs&&fs.length){ lib.folders=fs; } fin(); }).catch(function(e){ L('cfgERR '+e.message); fin(); });
  }
  var STEAMRE=/no_steam|steam_offline|not_connected|steam[_\s.-]*offline|Steam\s*错误|连接无法初始化|could not be initialized|Steam\s*Error/i;
  function never(){ return new Promise(function(){}); }
  function patchModal(){
    try{
      var inj=angular.element(document.body).injector(); if(!inj) return;
      // 1) 应用自己的 modals 服务（utils.showSteamError 走的是它，title 还是原始 key）
      try{
        var md=inj.get('modals');
        if(md && !md.__wefpPatched && typeof md.open==='function'){
          var o2=md.open;
          md.open=function(t,op){
            try{
              var d=(op&&op.data)||{}; var sg=[t,d.title,d.message].join('|');
              if(STEAMRE.test(sg)){ L('quiet: suppressed modals.open '+sg); return never(); }
            }catch(e){}
            return o2.apply(md,arguments);
          };
          md.__wefpPatched=1; L('quiet: modals patched');
        }
      }catch(e){ L('modalsPATCHERR '+e.message); }
      // 2) $uibModal 兜底（标题可能已被翻译成「Steam 错误」）
      var m=inj.get('$uibModal');
      if(m && !m.__wefpPatched && typeof m.open==='function'){
        var orig=m.open;
        m.open=function(o){
          try{
            var d=(o&&o.data)||{}; var sg=String(d.title||'')+'|'+String(d.message||'');
            if(STEAMRE.test(sg)){
              L('quiet: suppressed $uibModal '+sg); var nv=never();
              return {result:nv,opened:nv,rendered:nv,close:function(){},dismiss:function(){}};
            }
          }catch(e){}
          return orig.apply(m,arguments);
        };
        m.__wefpPatched=1; L('quiet: $uibModal patched');
      }
    }catch(e){ L('modalERR '+e.message); }
  }
  function killSteamModal(){
    try{
      var ms=document.querySelectorAll('.modal');
      for(var i=0;i<ms.length;i++){
        var el=ms[i], t=(el.textContent||'');
        if(!STEAMRE.test(t)) continue;
        L('quiet: closing steam modal '+t.replace(/\s+/g,' ').slice(0,60));
        try{ var sc=angular.element(el).scope(); if(sc&&sc.$dismiss) sc.$dismiss(); }catch(e){}
        try{ var p=el.parentNode; if(p&&p.removeChild) p.removeChild(el); }catch(e){}
      }
      var bd=document.querySelectorAll('.modal-backdrop');
      for(var k=0;k<bd.length;k++){ bd[k].style.setProperty('display','none','important'); }
    }catch(e){}
  }
  function quietSteam(){
    killSteamModal();
    try{
      var els=document.querySelectorAll('.browseAlert');
      for(var i=0;i<els.length;i++){
        var el=els[i]; if(el.__wefpQuiet) continue;
        if(String(el.className).indexOf('ng-hide')>=0) continue;
        var t=(el.textContent||'').replace(/\s+/g,' ').trim();
        if(/离线|未连接|已断开|offline|backup|备份/i.test(t)){
          el.style.setProperty('display','none','important'); el.__wefpQuiet=1;
          L('quiet: hid alert '+t.slice(0,80));
        }
      }
      if(S && S.steamWorkshopStatus && !S.steamWorkshopStatus.hidden){
        S.steamWorkshopStatus.hidden=true;
        try{ S.$applyAsync(); }catch(e){}
      }
    }catch(e){}
  }
  function quietTick(){ patchModal(); quietSteam(); }
  function guardReload(){
    try{
      window.addEventListener('keydown',function(e){
        var k=(e.key||'').toLowerCase(), ctrl=e.ctrlKey||e.metaKey;
        if(k==='f5' || (ctrl && k==='r')){
          e.preventDefault(); e.stopPropagation();
          toast('刷新会让引擎丢掉已加载的壁纸列表（会变成空白）。要重开界面：关掉这个窗口，再点托盘图标。', 7000);
          return false;
        }
      },true);
    }catch(e){}
  }
  function init(){
    var tries=0;
    (function wait(){
      S=pickScope();
      if(S){ loadLib(function(){ guardReload(); buildUI(); startWatch(); }); }
      else if(++tries<50){ setTimeout(wait,400); }
      else { L('no scope'); }
    })();
  }
  function startWatch(){
    var n=0;
    var t=setInterval(function(){ n++; renderBody(); if(n>40) clearInterval(t); },1500);
  }
  window.__wefp.api={
    openFolder:function(t){ var f=null; (function scan(a){ a.forEach(function(x){ if(x.title===t&&!f) f=x; scan(subsOf(x)); }); })(roots()); if(f){ if(subsOf(f).length){ path=[]; enter(f); } else openFolder(f); } return f?f.title:null; },
    openTag:openTag, openAll:openAll, back:backToFolders, render:renderBody, showGrid:showGrid, hideGrid:hideGrid, roots:function(){ var v=validKeys(); return roots().map(function(f){ return {t:f.title,n:itemsCount(f,v),all:countAll(f,v),subs:subsOf(f).length}; }); },
    state:function(){ return {path:path.map(function(f){return f.title;}), level:level().map(function(f){return f.title;}), ver:window.__wefp.ver,
      overlay:overlay?overlay.style.display:'none', fab:fab?{l:fab.style.left,t:fab.style.top,w:fab.offsetWidth,h:fab.offsetHeight}:null,
      gridHidden:document.documentElement.classList.contains('wefp-hidegrid')}; },
    togglePanel:togglePanel, openPanel:openPanel, closePanel:closePanel,
    fabSet:openFabSet, pickFab:pickFabImage, setFabImage:function(u){ try{ localStorage.setItem('wefp.fabimg',u); localStorage.setItem('wefp.fabuser','1'); }catch(e){} applyFabImage(u,true); },
    fabCfg:function(o){ if(o){ if(o.size) fabCfg.size=+o.size; if(o.shape) fabCfg.shape=o.shape; if(o.start) fabCfg.start=o.start; applyFabCfg(); saveFabPrefs(); markShapeBtns(); if(typeof markStartBtns==='function') markStartBtns(); if(o.start){ if(o.start==='ball'){ closePanel(); hideGrid(); } else { openPanel(); } } } return {size:fabCfg.size,shape:fabCfg.shape,w:(fab?fab.offsetWidth:0),h:(fab?fab.offsetHeight:0),radius:(fab?fab.style.borderRadius:'')}; },
    clearFabImage:function(){ try{ localStorage.removeItem('wefp.fabimg'); localStorage.removeItem('wefp.fabuser'); }catch(e){} applyFabImage('',true); },
    hasImg:function(){ return !!(fab&&fab.classList.contains('hasimg')); },
    moveFab:function(l,t){ if(fab){ fab.style.left=l+'px'; fab.style.top=t+'px'; try{ localStorage.setItem('wefp.fabpos', JSON.stringify({l:l,t:t})); }catch(e){} } return fab?[fab.style.left,fab.style.top]:null; } };
  quietTick(); setInterval(quietTick,1200);
  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();