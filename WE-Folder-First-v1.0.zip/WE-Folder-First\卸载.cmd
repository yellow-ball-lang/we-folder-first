@echo off
chcp 65001 >nul
title WE Folder First - Uninstall
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0卸载.ps1"
echo.
pause