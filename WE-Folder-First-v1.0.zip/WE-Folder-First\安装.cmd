@echo off
chcp 65001 >nul
title WE Folder First - Install
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0安装.ps1"
echo.
pause