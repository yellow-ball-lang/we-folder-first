﻿#requires -Version 5.1
<#
  WE Folder First —— 开机自动修复（可选）
  作用：把「修复」逻辑装到 %LOCALAPPDATA%\WEFolderFirst，并写一条 HKCU 启动项。
        Steam 更新 Wallpaper Engine 后，下次登录会自动发现注入失效并重装。
        只需普通用户权限，不需要管理员、不写计划任务。

  开启：双击「自动修复.cmd」，或
        powershell -NoProfile -ExecutionPolicy Bypass -File .\自动修复.ps1
  取消：powershell -NoProfile -ExecutionPolicy Bypass -File .\自动修复.ps1 -Remove
        （或双击「取消自动修复.cmd」）
#>
param(
  [switch]$Remove,
  [switch]$Quiet,
  [string]$KitDir = ''
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$valName = 'WEFolderFirstRepair'
$runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
if (-not $KitDir) { $KitDir = Join-Path $env:LOCALAPPDATA 'WEFolderFirst' }

function Say($m) { if (-not $Quiet) { Write-Host $m } }

# ---------- 取消 ----------
if ($Remove) {
  try { Remove-ItemProperty -Path $runKey -Name $valName -ErrorAction Stop; Say '已删除开机启动项。' }
  catch { Say '开机启动项本来就不存在。' }
  if (Test-Path $KitDir) {
    Remove-Item $KitDir -Recurse -Force -ErrorAction SilentlyContinue
    Say "已删除 $KitDir"
  }
  Say ''
  Say '已取消开机自动修复。Steam 更新后需要手动双击「修复.cmd」。'
  exit 0
}

# ---------- 检查源文件 ----------
foreach ($f in @('修复.ps1', '安装.ps1', 'wefolderfirst.js')) {
  if (-not (Test-Path (Join-Path $here $f))) {
    Write-Host "!! 同目录缺少 $f，请把压缩包完整解压后再运行"
    exit 1
  }
}

# ---------- 复制到固定目录 ----------
New-Item -ItemType Directory -Path $KitDir -Force | Out-Null
Copy-Item (Join-Path $here '修复.ps1')         (Join-Path $KitDir 'repair.ps1')        -Force
Copy-Item (Join-Path $here '安装.ps1')         (Join-Path $KitDir '安装.ps1')          -Force
Copy-Item (Join-Path $here 'wefolderfirst.js') (Join-Path $KitDir 'wefolderfirst.js')  -Force

# ---------- 记住 WPE 位置（记不住也让 repair.ps1 自己找） ----------
$wpe = $null
foreach ($k in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
  if ($wpe) { break }
  try {
    $it = Get-ItemProperty $k -ErrorAction Stop
    $root = $null
    if ($it.SteamPath) { $root = $it.SteamPath } elseif ($it.InstallPath) { $root = $it.InstallPath }
    if (-not $root) { continue }
    $c = Join-Path $root 'steamapps\common\wallpaper_engine'
    if (Test-Path (Join-Path $c 'ui\dist\index.html')) { $wpe = $c; break }
    $vdf = Join-Path $root 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
      foreach ($m in [regex]::Matches([IO.File]::ReadAllText($vdf), '"path"\s+"([^"]+)"')) {
        $c = Join-Path (($m.Groups[1].Value -replace '\\\\', '\')) 'steamapps\common\wallpaper_engine'
        if (Test-Path (Join-Path $c 'ui\dist\index.html')) { $wpe = $c; break }
      }
    }
  } catch { }
}
$wpeFile = Join-Path $KitDir 'wpepath.txt'
if ($wpe -and ($wpe -match '^[\x20-\x7E]+$')) {
  [IO.File]::WriteAllText($wpeFile, $wpe, (New-Object Text.ASCIIEncoding))
} elseif (Test-Path $wpeFile) {
  Remove-Item $wpeFile -Force   # 路径含中文就不记，开机时自动查找
}

# ---------- 生成 run.vbs（wscript 启动，不闪黑窗；纯 ASCII） ----------
$vbsLines = @(
  "' WE Folder First - logon self-check / repair (generated, do not edit)",
  'Dim sh, fso, p, arg, t',
  'Set sh = CreateObject("WScript.Shell")',
  'Set fso = CreateObject("Scripting.FileSystemObject")',
  'p = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))',
  'arg = ""',
  'If fso.FileExists(p & "wpepath.txt") Then',
  '  t = Trim(fso.OpenTextFile(p & "wpepath.txt", 1).ReadAll())',
  '  t = Replace(Replace(Replace(t, Chr(239), ""), Chr(187), ""), Chr(191), "" )',
  '  If Len(t) > 3 Then arg = " -WpePath """ & t & """"',
  'End If',
  'sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & p & "repair.ps1"" -Quiet" & arg, 0, False'
)
Set-Content -Path (Join-Path $KitDir 'run.vbs') -Value ($vbsLines -join "`r`n") -Encoding ASCII

# ---------- 写启动项 ----------
$cmd = 'wscript.exe "' + (Join-Path $KitDir 'run.vbs') + '"'
if (-not (Test-Path $runKey)) { New-Item -Path $runKey -Force | Out-Null }
Set-ItemProperty -Path $runKey -Name $valName -Value $cmd

Say '已开启开机自动修复。'
Say ("  安装位置 : " + $KitDir)
Say ("  启动项   : HKCU\Software\Microsoft\Windows\CurrentVersion\Run\" + $valName)
Say ("  WPE 位置 : " + $(if ($wpe) { $wpe } else { '（开机时自动查找）' }))
Say ''
Say '登录时静默跑一次，不弹窗：注入正常就什么都不做，Steam 更新过才会自动重装。'
Say '不想要了就双击「取消自动修复.cmd」。'
exit 0