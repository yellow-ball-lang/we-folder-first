﻿#requires -Version 5.1
<#
  WE Folder First —— 自检 / 一键修复
  用途：Steam 更新 Wallpaper Engine 后，ui\dist 被覆盖，注入会失效。
        双击「修复.cmd」即可检查并重新装好（不用先卸载）。

  也可静默运行（给计划任务用）：
    powershell -NoProfile -ExecutionPolicy Bypass -File .\修复.ps1 -Quiet
  退出码：0 = 正常或已修好；1 = 找不到 Wallpaper Engine 或修复失败
#>
param(
  [string]$WpePath = '',
  [switch]$Quiet
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$marker = 'wefolderfirst.js'

function Say($m) { if (-not $Quiet) { Write-Host $m } }

function Get-SteamLibs {
  $roots = @()
  foreach ($k in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
    try {
      $it = Get-ItemProperty $k -ErrorAction Stop
      if ($it.SteamPath) { $roots += $it.SteamPath }
      elseif ($it.InstallPath) { $roots += $it.InstallPath }
    } catch { }
  }
  $roots += 'C:\Program Files (x86)\Steam'
  $libs = @()
  foreach ($r in ($roots | Where-Object { $_ } | Select-Object -Unique)) {
    if (-not (Test-Path $r)) { continue }
    $libs += (Join-Path $r 'steamapps')
    $vdf = Join-Path $r 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
      try {
        $txt = Get-Content $vdf -Raw -ErrorAction Stop
        foreach ($m in [regex]::Matches($txt, '"path"\s+"([^"]+)"')) {
          $libs += (Join-Path ($m.Groups[1].Value -replace '\\\\', '\') 'steamapps')
        }
      } catch { }
    }
  }
  $libs | Where-Object { $_ } | Select-Object -Unique
}

# ---------- 1. 定位 Wallpaper Engine ----------
$wpe = $null
if ($WpePath -and (Test-Path (Join-Path $WpePath 'ui\dist\index.html'))) {
  $wpe = $WpePath
} elseif ($WpePath) {
  Say "记下的位置已失效（$WpePath），改为自动查找 ..."
}
if (-not $wpe) {
  foreach ($lib in (Get-SteamLibs)) {
    $p = Join-Path $lib 'common\wallpaper_engine'
    if (Test-Path (Join-Path $p 'ui\dist\index.html')) { $wpe = $p; break }
  }
}
if (-not $wpe) {
  if ($Quiet) { exit 1 }
  Say '没自动找到 Wallpaper Engine，请把安装目录粘进来（含 wallpaper32.exe 的那个文件夹）：'
  $wpe = (Read-Host '安装目录').Trim('"').Trim()
  if (-not $wpe) { Write-Host '没有输入目录，已退出。'; exit 1 }
}

$dist  = Join-Path $wpe 'ui\dist'
$index = Join-Path $dist 'index.html'
$js    = Join-Path $dist 'scripts\wefolderfirst.js'
$cfg   = Join-Path $dist 'scripts\wefp'

if (-not (Test-Path $index)) {
  Say "!! 这个目录里没有 ui\dist\index.html：$wpe"
  exit 1
}

# ---------- 2. 自检 ----------
$htmlOk = ([IO.File]::ReadAllText($index) -match [regex]::Escape($marker))
$jsOk   = (Test-Path $js) -and ((Get-Item $js).Length -gt 2000)
$cfgOk  = Test-Path (Join-Path $cfg 'index.html.orig')

Say "Wallpaper Engine: $wpe"
Say ("  注入标记 index.html : " + $(if ($htmlOk) { '正常' } else { '缺失 ← Steam 更新覆盖过' }))
Say ("  脚本 wefolderfirst.js : " + $(if ($jsOk) { '正常' } else { '缺失或损坏' }))
Say ("  备份 index.html.orig  : " + $(if ($cfgOk) { '存在' } else { '缺失（会重新生成）' }))

if ($htmlOk -and $jsOk -and $cfgOk) {
  Say ''
  Say '一切正常，不需要修复。'
  exit 0
}

# ---------- 3. 修复：直接跑安装器（它自己会刷新备份、跳过已有数据） ----------
Say ''
Say '正在重新安装注入 ...'
$installer = Join-Path $here '安装.ps1'
if (-not (Test-Path $installer)) {
  Say "!! 同目录里找不到 安装.ps1，请把整个文件夹解压完整后再试"
  exit 1
}
try {
  & $installer -WpePath $wpe
} catch {
  Say "!! 修复失败：$($_.Exception.Message)"
  Say '   如果 Wallpaper Engine 装在 Program Files 下，请右键「修复.cmd」→ 以管理员身份运行。'
  exit 1
}

# ---------- 4. 复检 ----------
$htmlOk2 = ([IO.File]::ReadAllText($index) -match [regex]::Escape($marker))
$jsOk2   = (Test-Path $js) -and ((Get-Item $js).Length -gt 2000)
if ($htmlOk2 -and $jsOk2 -and (Test-Path (Join-Path $cfg 'index.html.orig'))) {
  Say ''
  Say '修复完成。关掉 Wallpaper Engine 库窗口 → 托盘图标退出 → 重新点托盘图标打开即可。'
  exit 0
}
Say ''
Say '!! 修复后自检仍未通过，请把上面的输出发给作者。'
exit 1