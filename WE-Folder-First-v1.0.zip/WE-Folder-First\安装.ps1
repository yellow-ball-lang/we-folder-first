﻿#requires -Version 5.1
<#
  WE Folder First 33 —— 让 Wallpaper Engine 自带界面先显示文件夹
  双击「安装.cmd」即可；也可直接：
    powershell -NoProfile -ExecutionPolicy Bypass -File .\安装.ps1
  可选： -WpePath "D:\SteamLibrary\steamapps\common\wallpaper_engine"
#>
param([string]$WpePath = '')

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$marker = 'wefolderfirst.js'

function Say($m) { Write-Host $m }
function Fail($m) { Write-Host ''; Write-Host "!! $m" -ForegroundColor Red; exit 1 }

# ---------- 1. 找 Steam 库 ----------
function Get-SteamLibs {
  $roots = @()
  foreach ($k in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
    try {
      $it = Get-ItemProperty $k -ErrorAction Stop
      if ($it.SteamPath) { $roots += $it.SteamPath }
      elseif ($it.InstallPath) { $roots += $it.InstallPath }
    } catch { }
  }
  $roots += 'C:\Program Files (x86)\Steam'
  $libs = @()
  foreach ($r in ($roots | Where-Object { $_ } | Select-Object -Unique)) {
    if (-not (Test-Path $r)) { continue }
    $libs += (Join-Path $r 'steamapps')
    $vdf = Join-Path $r 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
      try {
        $txt = Get-Content $vdf -Raw -ErrorAction Stop
        foreach ($m in [regex]::Matches($txt, '"path"\s+"([^"]+)"')) {
          $libs += (Join-Path ($m.Groups[1].Value -replace '\\\\', '\') 'steamapps')
        }
      } catch { }
    }
  }
  $libs | Where-Object { $_ } | Select-Object -Unique
}

function Find-Wpe([string]$explicit) {
  if ($explicit) {
    if (Test-Path (Join-Path $explicit 'ui\dist\index.html')) { return $explicit }
    Fail "指定的目录里没有 ui\dist\index.html：$explicit"
  }
  foreach ($lib in (Get-SteamLibs)) {
    $p = Join-Path $lib 'common\wallpaper_engine'
    if (Test-Path (Join-Path $p 'ui\dist\index.html')) { return $p }
  }
  return $null
}

Say '正在查找 Wallpaper Engine ...'
$wpe = Find-Wpe $WpePath
if (-not $wpe) {
  Say ''
  Say '没自动找到 Wallpaper Engine。请把它的安装目录粘进来（含 wallpaper32.exe 的那个文件夹），'
  Say '例如：D:\SteamLibrary\steamapps\common\wallpaper_engine'
  $manual = Read-Host '安装目录'
  $manual = $manual.Trim('"').Trim()
  if (-not $manual) { Fail '没有输入目录，已退出。' }
  $wpe = Find-Wpe $manual
}

$dist = Join-Path $wpe 'ui\dist'
$index = Join-Path $dist 'index.html'
$cfgDir = Join-Path $dist 'scripts\wefp'
$jsDst = Join-Path $dist 'scripts\wefolderfirst.js'
Say "Wallpaper Engine: $wpe"

# ---------- 2. 写文件（先测权限） ----------
try {
  New-Item -ItemType Directory -Force -Path $cfgDir | Out-Null
} catch {
  Fail "没有写入权限：$cfgDir`n   如果 Wallpaper Engine 装在 Program Files 下，请右键「安装.cmd」→ 以管理员身份运行。"
}

$origFile = Join-Path $cfgDir 'index.html.orig'
$htmlNow = [IO.File]::ReadAllText($index)
$alreadyInjected = ($htmlNow -match [regex]::Escape($marker))
if (-not $alreadyInjected) {
  # 当前 index.html 不含注入 => 这是原厂文件（首次安装，或 Steam 更新后覆盖了）
  Copy-Item $index $origFile -Force
  if (Test-Path $origFile) { Say '已备份原始 index.html（若刚更新过 Steam，这里会刷新为新版备份）' }
} elseif (-not (Test-Path $origFile)) {
  # 已经注入过但没备份（例如早前手动装过）：把注入那一行去掉，重建一份原始备份
  $rebuilt = [regex]::Replace($htmlNow, '\s*<script src="scripts/wefolderfirst\.js"></script>', '')
  [IO.File]::WriteAllText($origFile, $rebuilt, (New-Object Text.UTF8Encoding($false)))
  Say '已从当前文件重建原始备份 scripts\wefp\index.html.orig（去掉了注入那一行）'
}

# ---------- 3. 悬浮球配置（仅首次） ----------
# 默认图标就是最初始的 📁（不使用任何自带图片）；想换图标：右键悬浮球 → 选择图片。
$groupsFile = Join-Path $cfgDir 'groups.json'
$fabCfgFile = Join-Path $cfgDir 'config.json'
if (-not (Test-Path $fabCfgFile)) {
  [IO.File]::WriteAllText($fabCfgFile, '{}', (New-Object Text.UTF8Encoding($false)))
  Say '已生成悬浮球配置 scripts\wefp\config.json（默认图标就是 📁，想换右键悬浮球→选择图片）'
}
if (-not (Test-Path $groupsFile)) {
  Say '正在扫描壁纸目录统计标签（几百个文件夹，约 1-3 秒）...'
  $dirs = @()
  foreach ($lib in (Get-SteamLibs)) {
    $w = Join-Path $lib 'workshop\content\431960'
    if (Test-Path $w) { $dirs += $w }
  }
  $mine = Join-Path $wpe 'projects\myprojects'
  if (Test-Path $mine) { $dirs += $mine }

  $rows = New-Object System.Collections.ArrayList
  foreach ($root in $dirs) {
    foreach ($d in (Get-ChildItem $root -Directory -ErrorAction SilentlyContinue)) {
      $pj = Join-Path $d.FullName 'project.json'
      if (-not (Test-Path $pj)) { continue }
      $tag = '未分类'
      try {
        $fs = [IO.File]::Open($pj, 'Open', 'Read', 'ReadWrite')
        $buf = New-Object byte[] 65536
        $n = $fs.Read($buf, 0, $buf.Length)
        $fs.Close()
        $text = [Text.Encoding]::UTF8.GetString($buf, 0, $n)
        $m = [regex]::Match($text, '"tags"\s*:\s*\[\s*"([^"]+)"')
        if (-not $m.Success) { $m = [regex]::Match($text, '"tags"\s*:\s*"([^"]+)"') }
        if ($m.Success -and $m.Groups[1].Value) { $tag = $m.Groups[1].Value }
      } catch { }
      [void]$rows.Add($tag)
    }
  }

  $agg = $rows | Group-Object | ForEach-Object { [pscustomobject]@{ name = $_.Name; count = $_.Count } } | Sort-Object count -Descending
  $out = [ordered]@{
    total  = $rows.Count
    groups = @($agg | ForEach-Object { [ordered]@{ name = $_.name; count = $_.count } })
  }
  [IO.File]::WriteAllText($groupsFile, ($out | ConvertTo-Json -Depth 4 -Compress), (New-Object Text.UTF8Encoding($false)))
  Say ("已统计：{0} 个壁纸 / {1} 个标签分组" -f $rows.Count, @($agg).Count)
} else {
  Say '已有 groups.json，跳过统计（想重算就删掉它再装一次）'
}

# ---------- 4. 装入脚本 ----------
$tpl = [IO.File]::ReadAllText((Join-Path $here 'wefolderfirst.js'))
$wsUnix = ($cfgDir -replace '\\', '/')
$tpl = $tpl.Replace('{{WS}}', $wsUnix)
$tpl = $tpl.Replace('{{WPE}}', ($wpe -replace '\\', '/'))
$tpl = $tpl.Replace('{{VER}}', '33')
[IO.File]::WriteAllText($jsDst, $tpl, (New-Object Text.UTF8Encoding($false)))
Say "已写入脚本: $jsDst"

$html = [IO.File]::ReadAllText($index)
if ($html -notmatch [regex]::Escape($marker)) {
  $tag = '<script src="scripts/wefolderfirst.js"></script>'
  if ($html -match '(?i)</head>') {
    $html = $html -replace '(?i)</head>', ($tag + '</head>')
  } else {
    $html = $tag + $html
  }
  [IO.File]::WriteAllText($index, $html, (New-Object Text.UTF8Encoding($false)))
  Say '已把脚本挂进 index.html'
} else {
  Say 'index.html 里已经有脚本，跳过'
}

@(
  "WE Folder First 33"
  "installed: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
  "wpe: $wpe"
  "groups: $groupsFile"
) | Set-Content (Join-Path $cfgDir 'install-info.txt') -Encoding UTF8

Say ''
Say '安装完成。让改动生效：'
Say '  1) 关掉 Wallpaper Engine 的库窗口；'
Say '  2) 右键托盘图标 → 退出 Wallpaper Engine；'
Say '  3) 重新打开 Wallpaper Engine，再点托盘图标打开库。'
Say ''
Say '以后想还原：双击「卸载.cmd」即可。'
Say ''
Say '小提示：Steam 更新 Wallpaper Engine 后界面会回到原版，双击「修复.cmd」即可补回来；'
Say '        想让它自动恢复，再双击一次「自动修复.cmd」（登录时静默自检，可随时取消）。'