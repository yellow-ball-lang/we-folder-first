@echo off
chcp 65001 >nul
title WE Folder First - Check / Repair
cd /d "%~dp0"
echo 检查 Wallpaper Engine 的界面注入是否还在（Steam 更新后可能会失效）...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0修复.ps1"
echo.
pause